<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Branch_Ledger extends Model
{
    /** @use HasFactory<\Database\Factories\BranchLedgerFactory> */
    use HasFactory;
    protected $guarded = [];
}
