<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Payment_Recived extends Model
{
    /** @use HasFactory<\Database\Factories\PaymentRecivedFactory> */
    use HasFactory;
    protected $guarded = [];
}
