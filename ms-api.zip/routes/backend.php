<?php

use Illuminate\Support\Facades\Route;

// Route::get('/', function () {
//     return 'Hello from backend route';
// });
